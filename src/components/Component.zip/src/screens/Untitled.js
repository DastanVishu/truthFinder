import React, { Component } from "react";
import { StyleSheet, View } from "react-native";
import ProfileBoard from "../components/ProfileBoard";
import FrequentlyCalles from "../components/FrequentlyCalles";
import RecorderPlayer from "../components/RecorderPlayer";

function Untitled(props) {
  return (
    <View style={styles.container}>
      <ProfileBoard style={styles.profileBoard}></ProfileBoard>
      <FrequentlyCalles style={styles.frequentlyCalles}></FrequentlyCalles>
      <RecorderPlayer style={styles.recorderPlayer}></RecorderPlayer>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "rgba(255,255,255,1)"
  },
  profileBoard: {
    height: 158,
    width: 349,
    marginTop: 70,
    marginLeft: 13
  },
  frequentlyCalles: {
    height: 116,
    width: 349,
    marginTop: 17,
    marginLeft: 13
  },
  recorderPlayer: {
    height: 149,
    width: 349,
    marginTop: 23,
    marginLeft: 13
  }
});

export default Untitled;
